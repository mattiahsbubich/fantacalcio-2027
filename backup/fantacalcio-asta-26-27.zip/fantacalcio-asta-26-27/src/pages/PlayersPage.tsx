function PlayersPage() {
  return (
    <section className="stack">
      <article className="panel">
        <h2>Listone giocatori</h2>
        <p>
          Qui inseriremo ricerca, filtri per ruolo, squadra, fascia e stato di acquisto.
        </p>
      </article>
      <div className="empty-state">
        <span aria-hidden="true">☷</span>
        <h3>Listone non ancora importato</h3>
        <p>Verrà convertito dal PDF allegato in una fase dedicata.</p>
      </div>
    </section>
  );
}

export default PlayersPage;
