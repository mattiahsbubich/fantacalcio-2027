export type PageId = 'home' | 'players' | 'auction' | 'strategy' | 'settings';

interface BottomNavigationProps {
  activePage: PageId;
  onChange: (page: PageId) => void;
}

const items: Array<{ id: PageId; label: string; icon: string }> = [
  { id: 'home', label: 'Home', icon: '⌂' },
  { id: 'players', label: 'Listone', icon: '☷' },
  { id: 'auction', label: 'Asta', icon: '€' },
  { id: 'strategy', label: 'Strategia', icon: '◎' },
  { id: 'settings', label: 'Impostazioni', icon: '⚙' }
];

function BottomNavigation({ activePage, onChange }: BottomNavigationProps) {
  return (
    <nav className="bottom-navigation" aria-label="Navigazione principale">
      {items.map((item) => (
        <button
          key={item.id}
          type="button"
          className={activePage === item.id ? 'active' : ''}
          onClick={() => onChange(item.id)}
          aria-current={activePage === item.id ? 'page' : undefined}
        >
          <span className="nav-icon" aria-hidden="true">{item.icon}</span>
          <span>{item.label}</span>
        </button>
      ))}
    </nav>
  );
}

export default BottomNavigation;
