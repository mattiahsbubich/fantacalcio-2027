function AuctionPage() {
  return (
    <section className="stack">
      <article className="panel accent-panel">
        <p className="eyebrow">Budget residuo</p>
        <strong className="big-number">500</strong>
        <p>Nessun giocatore acquistato.</p>
      </article>

      <article className="panel">
        <h2>Gestione asta</h2>
        <p>
          Qui aggiungeremo acquisto rapido, prezzo pagato, modifica, rimozione e
          annullamento dell’ultima operazione.
        </p>
        <button className="primary-button" type="button" disabled>
          Aggiungi giocatore
        </button>
      </article>
    </section>
  );
}

export default AuctionPage;
