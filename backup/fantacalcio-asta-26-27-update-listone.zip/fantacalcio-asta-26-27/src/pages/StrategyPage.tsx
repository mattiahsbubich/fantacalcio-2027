function StrategyPage() {
  return (
    <section className="stack">
      <article className="panel">
        <h2>Strategia personale</h2>
        <p>
          Questa sezione ospiterà fasce, prezzi consigliati, note e abbinamenti
          tra portieri, centrocampisti e attaccanti.
        </p>
      </article>
    </section>
  );
}

export default StrategyPage;
