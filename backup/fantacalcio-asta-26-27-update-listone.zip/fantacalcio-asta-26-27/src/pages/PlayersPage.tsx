import { useMemo, useState } from 'react';
import { initialPlayers } from '../data/initialPlayers';
import type { PlayerRole } from '../types/player';

const roles: Array<{ id: PlayerRole | 'ALL'; label: string; shortLabel: string }> = [
  { id: 'ALL', label: 'Tutti', shortLabel: 'Tutti' },
  { id: 'P', label: 'Portieri', shortLabel: 'P' },
  { id: 'D', label: 'Difensori', shortLabel: 'D' },
  { id: 'C', label: 'Centrocampisti', shortLabel: 'C' },
  { id: 'A', label: 'Attaccanti', shortLabel: 'A' }
];

const roleNames: Record<PlayerRole, string> = {
  P: 'Portiere',
  D: 'Difensore',
  C: 'Centrocampista',
  A: 'Attaccante'
};

function PlayersPage() {
  const [query, setQuery] = useState('');
  const [activeRole, setActiveRole] = useState<PlayerRole | 'ALL'>('ALL');

  const filteredPlayers = useMemo(() => {
    const normalizedQuery = query.trim().toLocaleUpperCase('it');

    return initialPlayers
      .filter((player) => activeRole === 'ALL' || player.role === activeRole)
      .filter((player) =>
        normalizedQuery.length === 0 ||
        player.name.includes(normalizedQuery) ||
        player.team.includes(normalizedQuery)
      )
      .sort((a, b) => a.name.localeCompare(b.name, 'it'));
  }, [activeRole, query]);

  return (
    <section className="players-page stack">
      <div className="listone-intro">
        <div>
          <p className="eyebrow">Stagione 2026/27</p>
          <h2>{initialPlayers.length} giocatori</h2>
          <p>Quotazioni iniziali riportate dal PDF del listone.</p>
        </div>
      </div>

      <label className="search-box">
        <span className="sr-only">Cerca per giocatore o squadra</span>
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <circle cx="11" cy="11" r="7" />
          <path d="m20 20-4-4" />
        </svg>
        <input
          type="search"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Cerca giocatore o squadra"
          autoComplete="off"
        />
        {query && (
          <button type="button" onClick={() => setQuery('')} aria-label="Cancella ricerca">
            ×
          </button>
        )}
      </label>

      <div className="role-tabs" aria-label="Filtra per ruolo">
        {roles.map((role) => {
          const count = role.id === 'ALL'
            ? initialPlayers.length
            : initialPlayers.filter((player) => player.role === role.id).length;

          return (
            <button
              key={role.id}
              type="button"
              className={activeRole === role.id ? 'active' : ''}
              onClick={() => setActiveRole(role.id)}
              aria-pressed={activeRole === role.id}
            >
              <span className="role-tab-long">{role.label}</span>
              <span className="role-tab-short">{role.shortLabel}</span>
              <small>{count}</small>
            </button>
          );
        })}
      </div>

      <div className="results-heading">
        <strong>{filteredPlayers.length} risultati</strong>
        <span>Ordine alfabetico</span>
      </div>

      {filteredPlayers.length > 0 ? (
        <div className="player-list">
          {filteredPlayers.map((player) => (
            <article className="player-row" key={player.id}>
              <div className={`role-avatar role-${player.role.toLowerCase()}`} aria-hidden="true">
                {player.role}
              </div>
              <div className="player-main">
                <strong>{player.name}</strong>
                <span>{roleNames[player.role]} · {player.team}</span>
              </div>
              <div className="player-price" aria-label={`${player.listPrice} fantamilioni`}>
                <strong>{player.listPrice}</strong>
                <span>FM</span>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <div className="empty-state compact-empty-state">
          <h3>Nessun giocatore trovato</h3>
          <p>Prova con un altro nome, una squadra o un ruolo differente.</p>
        </div>
      )}
    </section>
  );
}

export default PlayersPage;
