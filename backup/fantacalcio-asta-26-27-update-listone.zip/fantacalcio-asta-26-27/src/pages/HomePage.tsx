import StatCard from '../components/StatCard';

function HomePage() {
  return (
    <section className="stack">
      <div className="hero-card">
        <p className="eyebrow">Scheletro iniziale</p>
        <h2>La tua asta, sempre a portata di mano.</h2>
        <p>
          Questa prima versione prepara navigazione, layout mobile, modalità scura,
          safe area iOS e supporto offline.
        </p>
      </div>

      <div className="stats-grid">
        <StatCard label="Budget" value="500" helper="Crediti iniziali" />
        <StatCard label="Spesi" value="0" helper="Nessun acquisto" />
        <StatCard label="Rosa" value="0 / 25" helper="Slot occupati" />
        <StatCard label="Listone" value="—" helper="Importazione nella fase 3" />
      </div>

      <article className="panel">
        <h3>Prossimi passi</h3>
        <p>
          Nella fase successiva aggiungeremo il modello dati, localStorage e un
          primo listone dimostrativo prima dell’importazione completa del PDF.
        </p>
      </article>
    </section>
  );
}

export default HomePage;
