import { useEffect, useState } from 'react';
import BottomNavigation, { type PageId } from './components/BottomNavigation';
import AuctionPage from './pages/AuctionPage';
import HomePage from './pages/HomePage';
import PlayersPage from './pages/PlayersPage';
import SettingsPage from './pages/SettingsPage';
import StrategyPage from './pages/StrategyPage';

const pageTitles: Record<PageId, string> = {
  home: 'Fantacalcio 2026/27',
  players: 'Listone',
  auction: 'Asta',
  strategy: 'Strategia',
  settings: 'Impostazioni'
};

function App() {
  const [page, setPage] = useState<PageId>('home');
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const updateStatus = () => setIsOnline(navigator.onLine);
    window.addEventListener('online', updateStatus);
    window.addEventListener('offline', updateStatus);

    return () => {
      window.removeEventListener('online', updateStatus);
      window.removeEventListener('offline', updateStatus);
    };
  }, []);

  const renderPage = () => {
    switch (page) {
      case 'players':
        return <PlayersPage />;
      case 'auction':
        return <AuctionPage />;
      case 'strategy':
        return <StrategyPage />;
      case 'settings':
        return <SettingsPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="app-shell">
      <header className="app-header">
        <div>
          <p className="eyebrow">Assistente personale</p>
          <h1>{pageTitles[page]}</h1>
        </div>
        <span className={`status-badge ${isOnline ? 'online' : 'offline'}`}>
          {isOnline ? 'Online' : 'Offline'}
        </span>
      </header>

      <main className="page-content">{renderPage()}</main>
      <BottomNavigation activePage={page} onChange={setPage} />
    </div>
  );
}

export default App;
