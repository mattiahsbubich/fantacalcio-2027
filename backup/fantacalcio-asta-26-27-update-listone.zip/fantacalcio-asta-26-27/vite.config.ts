import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';

const repositoryName = 'fantacalcio-asta-26-27';

export default defineConfig({
  base: `/${repositoryName}/`,
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      includeAssets: ['favicon.svg', 'icons/apple-touch-icon.png'],
      manifest: {
        name: 'Fantacalcio Asta 2026/27',
        short_name: 'Fanta Asta',
        description: 'Assistente personale offline per il fantacalcio 2026/27.',
        theme_color: '#10131a',
        background_color: '#10131a',
        display: 'standalone',
        orientation: 'portrait-primary',
        start_url: `/${repositoryName}/`,
        scope: `/${repositoryName}/`,
        icons: [
          {
            src: 'icons/pwa-192x192.png',
            sizes: '192x192',
            type: 'image/png'
          },
          {
            src: 'icons/pwa-512x512.png',
            sizes: '512x512',
            type: 'image/png'
          },
          {
            src: 'icons/pwa-maskable-512x512.png',
            sizes: '512x512',
            type: 'image/png',
            purpose: 'maskable'
          }
        ]
      },
      workbox: {
        navigateFallback: 'index.html',
        globPatterns: ['**/*.{js,css,html,ico,png,svg,webmanifest}']
      }
    })
  ]
});
